#include "mcintegrator.h"

#include <stdio.h>
#include <iostream>
#include <iomanip>

using namespace std;

int main (int argc, char* argv[])
{

  char outfilename[] = "outfile.dat";

  MCIntegrator *integrator = new MCIntegrator();
  
  ofstream ofile;    

  ofile.open(outfilename); 
  
  for(int a = 0;  a < 200; a++) {
    
    double x = 0.01 + (double)a*0.05;
    
    double res = integrator->runMCIntegration(x,1.8,0.2);
    
    ofile << setiosflags(ios::showpoint | ios::uppercase);
    ofile << setw(15) << setprecision(8) << x;
    ofile << setw(15) << setprecision(8) << res << endl;
    
  }
  

  delete integrator;
  
  return(0);

}
