#include <iostream>
#include <stdio.h>

using namespace std;

int main (int argc, char* argv[])
{

 
  printf("Hello, world");
  
  return(0);

}
