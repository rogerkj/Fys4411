%Laste fil
filedata = load('outfile.dat');

%Finne antall element i fila
Number_cycles = size(filedata,1);
%Kan loope over dette for å finne som funksjon av blocksize

numb = 1:5:50000;

variance = zeros(size(numb,2));

%Loope over alle block sizes
for (t = 1:size(numb,2))

    %Plukke ut antall blocks
    blocksize = numb(t);
  

    %Initialisering
    number_blocks = 0;
    Tempsize = Number_cycles;
    
    %Finne antall blocks
    while (Tempsize > 0)
        Tempsize = Tempsize - blocksize;
        number_blocks = number_blocks + 1;
    end

    Energy = zeros(number_blocks-1,1);

    %Sette opp array med energiar
    for (i=1:number_blocks-1)
        for (j=1:blocksize)
            %Plukker ut energien
            Energytemp = filedata((i-1)*blocksize + j, 1);
        
            %Summerer opp disse
            Energy(i) = Energy(i) + Energytemp;
        end
    end

    Energy = Energy/blocksize;

    %Nulle ut variablar
    S = 0;
    E = 0;

    %Summere opp engergi og energi i andre
    for (i=1:number_blocks-1)
        E = E + Energy(i);
        S = S + Energy(i) * Energy(i);
    end

    E = E / (number_blocks-1);
    S = S / (number_blocks-1);

    %Finne variansen
    variance(t) = sqrt((S-E*E)/(number_blocks-1));
end

plot(numb, variance)

