/*
//
//          MPI.cpp
//
//          MC Integrator
//
//          Roger Kj�de
//
*/


#include "mcintegrator.h"
#include <mpi.h>
#include "lib.h"



#include <armadillo>
#include <stdio.h>
#include <iostream>
#include <iomanip>

using namespace std;

//Used to store info about the parts of the calculation
struct parts {double res; int el_a; int el_b; double val_a;double val_b;int element; bool isdone;};

//Used to send feedback to master proc
struct result {double res; int element; int iam;};


//Entry point
int main(int argc, char* argv[])
{
 
//---  Changeable values  -----

  char outfilename[] = "outfile.dat";

  const int A = 16;
  const int B = 16;
  
  
  
  //------------------------------
  
  int N = A*B;

  int numprocs, my_rank;
  MPI_Status status;
  
  //Init MPI
  MPI_Init (&argc, &argv);
  
  //Get number of procs and the rank of this proc
  MPI_Comm_size (MPI_COMM_WORLD, &numprocs);
  MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);
  
  //Simple check for number of procs
  if (numprocs == 1) {
    printf("Number of nodes must be over 1!");
    MPI_Finalize ();
    return 0;
  }
  
  //Master proc  Deligates tasks and collects feedback
  if(my_rank == 0) {
    
    parts* part = new parts[N];

    //Used to store info of all the calculation parts
    
    int t = 0;

    for(int a = 0;  a < A; a++) {
      for(int b = 0;  b < B; b++) {
	part[t].el_a = a;
	part[t].el_b = b;

	part[t].val_a = 9.5 + 0.25*(double)a/(double)A;
	part[t].val_b = 0.0005 + 0.0025*(double)b/(double)B;

	part[t].element = t;

	part[t].isdone = false;

	t++;
      }
    }
    
    //If we have more processes than tasks
    int nextpart = numprocs - 1;
    if (N < numprocs) nextpart = N;
    
    //Send tasks to all procs
    for (int t2 = 1;  t2 <= nextpart ; t2++ ) {
      
      MPI_Send (&part[t2-1],sizeof(parts), MPI_BYTE,t2,100, MPI_COMM_WORLD);
    }
    
    //Used to store feedback
    result* answer = new result;
    
    //Used to tell procs to terminate.
    parts* donedummy = new parts;
    donedummy->isdone = true;
    
    int nrdone = 0;
    
    //Main feedback look
    do {
      //Wait for proc to send result
      MPI_Recv (answer,sizeof(result), MPI_BYTE, MPI_ANY_SOURCE, 100,MPI_COMM_WORLD, &status);
      
      //Store result
      
      part[answer->element].res = answer->res;

      part[answer->element].isdone = true;
      
      
      
      //Send proc new task or terminate proc if no more tasks available
      if(nextpart<N) {
	MPI_Send (&part[nextpart],sizeof(parts), MPI_BYTE,answer->iam, 100,MPI_COMM_WORLD);
      } else {
	MPI_Send (donedummy,sizeof(parts), MPI_BYTE,answer->iam, 100,MPI_COMM_WORLD);
      }
      
      //Index to next task incremented
      nextpart++;
      nrdone++;
      
    } while (nrdone < N);
    //Loop until all calculations are in
    
    ofstream ofile;    

    ofile.open(outfilename); 

    t = 0;

    for(int a = 0;  a < A; a++) {
      for(int b = 0;  b < B; b++) {

      ofile << setiosflags(ios::showpoint | ios::uppercase);
      ofile << setw(15) << setprecision(8) << part[t].val_a;
      ofile << setw(15) << setprecision(8) << part[t].val_b;
      ofile << setw(15) << setprecision(8) << part[t].res << endl;

      t++;
      
      }

      ofile << endl;

    }

    ofile.close();  

    printf("All work done!");
    
    //All done!
    //All slave procs should now (or soon) be terminated.
    
  } else {
    //Slave proc. Recives a task and replies an answer.
    
    //No use for me? Goodbye cruel world!
    if (N < my_rank) {
      MPI_Finalize();
      return 0;
    }
    
    MCIntegrator *integrator = new MCIntegrator();
    
    //Used to store task and answer info
    parts* task = new parts;
    result* anser = new result;
    
    
    //Recive taks and send answer loop
    do {
      
      //Waits for new task.
      MPI_Recv (task, sizeof(parts), MPI_BYTE, 0 , 100,MPI_COMM_WORLD, &status);
      
      //Terminate proc. Not needed anymore
      if(task->isdone) break;
      
      //Do calculations
      anser->res = integrator->runMCIntegration(task->val_a,task->val_b);
      
      anser->iam = my_rank;
      anser->element = task->element;
      
      //Send result to master proc 
      MPI_Send (anser, sizeof(result), MPI_BYTE, 0,100, MPI_COMM_WORLD);

      //Just loop
    } while(true);
  
    delete integrator;

  }
  
  //All done!
  MPI_Finalize ();
  
  return 0;
}
