#include "mcintegrator.h"

#include <iostream>

using namespace std;

int main (int argc, char* argv[])
{

  MCIntegrator *integrator = new MCIntegrator();
  
  double h = 0.3;

  double a = 1.8;
  double b = 1.2;

  double t;

  while (t < 20) {

    double fxah = integrator->runMCIntegration(a+h,b);
    double fxbh = integrator->runMCIntegration(a,b+h);
    double fx  = integrator->runMCIntegration(a,b);
    
    double dmda = (fxah - fx)/h;
    double dmdb = (fxbh - fx)/h;
    
    a -= dmda * 0.5;
    b -= dmdb * 0.5;

    cout << "a:" << a << " b:" << b << endl;

    t++;

  }

  delete integrator;
  
  return(0);

}

